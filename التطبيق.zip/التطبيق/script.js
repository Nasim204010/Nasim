 // تحديد العناصر
const complaintForm = document.getElementById('complaintForm');
const complaintsGrid = document.getElementById('complaintsGrid');

// التعامل مع إرسال النموذج
complaintForm.addEventListener('submit', function (event) {
    event.preventDefault();

    // الحصول على قيم الحقول
    const name = document.getElementById('name').value.trim();
    const product = document.getElementById('product').value.trim();
    const complaint = document.getElementById('complaint').value.trim();

    if (name && product && complaint) {
        // إنشاء بطاقة شكوى
        const card = document.createElement('div');
        card.className = 'complaint-card';

        // إضافة محتوى الشكوى
        card.innerHTML = `
            <h3>${name}</h3>
            <p><strong>المنتج/الخدمة:</strong> ${product}</p>
            <p><strong>الشكوى:</strong> ${complaint}</p>
        `;

        // إضافة البطاقة إلى الشبكة
        complaintsGrid.appendChild(card);

        // تفريغ الحقول
        complaintForm.reset();
    } else {
        alert('يرجى ملء جميع الحقول');
    }
});
